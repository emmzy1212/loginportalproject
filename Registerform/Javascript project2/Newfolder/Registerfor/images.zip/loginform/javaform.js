let password = "Staylow";
let Email = "emmzy1212@yahoo.com";
let attempts = 3;

function login() {
    let emailInput = document.getElementById('inputEmail4').value;
    let passwordInput = document.getElementById('inputPassword4').value;

    if (emailInput === Email && passwordInput === password) {
        alert("Access granted");
        alert(`Welcome to the gateway of Emmzocoderacademy. ${emailInput}`);
        // Redirecting to a new file location
        window.location.href = "form.html"; // Replace "new_page.html" with your desired file location
    } else {
        alert('Incorrect email or password.');
        attempts--;
        if (attempts === 0) {
            alert('You have exceeded the maximum number of attempts.');
            document.getElementById('submit').disabled = true;
        }
    }
}