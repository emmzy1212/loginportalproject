let password = "Staylow";
let Email = "emmzy1212@yahoo.com"
let attempts = 3;
let input;


let submit = document.getElementById('submit')




function login(){
    let Email = document.getElementById('inputEmail4')
    let passworde =document.getElementById('inputPassword4').value


    let validPass = password ===passworde
    let validusername = Email ===Email

    let EmailE=inputEmail4.value
    console.log(EmailE)

      if(EmailE==Email || passworde==password){
        alert("access granted")
        alert(`You are now a student of melodia ${EmailE}`)
     } else if(password!==passworde ||EmailE!==Email ) {
        alert('password and email not match')
        alert('fill all filed correctly')
        alert('Try again')

    } 
   

     }