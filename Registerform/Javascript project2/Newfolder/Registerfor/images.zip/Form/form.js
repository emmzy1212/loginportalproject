// let Email = "emmzy12@yahoo.com";
// let pass = "Staylow"
// let Name = "John"
// let lname = "william"
// let attempts = 3;
// let input;


// let submit = document.getElementById('submit')






// function login(){
//     let Namee = document.getElementById('inputfirstname')
//     let Namel = document.getElementById('inputlastname')
//     let Email = document.getElementById('inputEmail4')
//     let pass =document.getElementById('inputPassword4').value


//     let validPass = Email === EmailE
//     let validusername = pass ===pass
//     let validname = Namee === Name
//     let validlastname = Namel === lname


//     let NamelE=inputlastname
//     console.log(NamelE)

//     let Name=inputfirstname.value
//     console.log(Name)

//     let EmailE=inputEmail4.value
//     console.log(EmailE)

//       if(EmailE==Email || pass==pass){
//         alert("access granted")
//         // window.Location= ("form.html")
//         alert(`welcome ${Name}`)
//      } else if(pass!==pass ||EmailE!==Email ) {
//         alert('password and username not match')
//         alert('fill all filed correctly')
//         alert('Try again')

//     } 
   

//      }

// .....
// firstname
// lastname
// let Email = "emmzy12@yahoo.com";
// let pass = "Staylow"
// let Name = "John"
// let lname = "william"
// let attempts = 3;
// let input;


// let submit = document.getElementById('submit')






// function login(){
//     let Namee = document.getElementById('inputfirstname')
//     let Namel = document.getElementById('inputlastname')
//     let Email = document.getElementById('inputEmail4')
//     let pass =document.getElementById('inputPassword4').value


//     let validPass = Email === EmailE
//     let validusername = pass ===pass
//     let validname = Namee === Name
//     let validlastname = Namel === lname


//     let NamelE=inputlastname
//     console.log(NamelE)

//     let Name=inputfirstname.value
//     console.log(Name)

//     let EmailE=inputEmail4.value
//     console.log(EmailE)

//       if(EmailE==Email || pass==pass){
//         alert("access granted")
//         // window.Location= ("form.html")
//         alert(`welcome ${Name}`)
//      } else if(pass!==pass ||EmailE!==Email ) {
//         alert('password and username not match')
//         alert('fill all filed correctly')
//         alert('Try again')

//     } 
   

//      }

// .....
// firstname
// lastname
let password = "Staylow";
let Email = "emmzy1212@yahoo.com"
let attempts = 3;
let input;


let submit = document.getElementById('submit')




function login(){
    let Email = document.getElementById('inputEmail4')
    let passworde =document.getElementById('inputPassword4').value
    let firstNameField = document.getElementById('inputfirstname').value;
    let lastNameField = document.getElementById('inputlastname').value;


    let validPass = password ===passworde
    let validusername = Email ===Email

    let EmailE=inputEmail4.value
    console.log(EmailE)

      if(EmailE==Email || passworde==password){
        alert("access granted")
        alert(`You are now a student of melodia ${firstNameField} ${lastNameField}`)
         // Navigate to a new file location
         window.location.href = 'form.html'; // Replace 'new_page.html' with your desired file location
     } else if(password!==passworde ||EmailE!==Email ) {
        alert('password and email not match')
        alert('fill all filed correctly')
        alert('Try again')

    } 
   

     }

   

   


   

   

